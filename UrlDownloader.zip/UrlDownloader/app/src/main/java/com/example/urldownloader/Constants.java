package com.example.urldownloader;

import android.os.Environment;

public class Constants {

    public static String FileDirectory = Environment.getExternalStorageDirectory().toString() + "TarangDownloader" ;
    public static String filename = FileDirectory +"/Downloader.mp4";
}
