package com.example.urldownloader;


import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

import at.huber.youtubeExtractor.VideoMeta;
import at.huber.youtubeExtractor.YouTubeExtractor;
import at.huber.youtubeExtractor.YouTubeUriExtractor;
import at.huber.youtubeExtractor.YtFile;

public class MainActivity extends AppCompatActivity {
    private EditText et_search;
    private Button button_download;
    private String newLink;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUi();
        getClickOnButtonDownload();
    }

    private void getClickOnButtonDownload() {
        button_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Url = et_search.getText().toString().trim();
                if(Url.isEmpty()){
                    Toast.makeText(MainActivity.this, "Url is required", Toast.LENGTH_SHORT).show();
                }else{
                     new YouTubeExtractor(MainActivity.this){
                        @Override
                        protected void onExtractionComplete(SparseArray<YtFile> ytFiles, VideoMeta videoMeta) {
                           // assertNotNull(ytFiles);
                            if (ytFiles != null) {
                                int numNotDash = 0;
                                int itag = 22;
                                for (int i = 0; i < ytFiles.size(); i++) {
                                    itag = ytFiles.keyAt(i);
                                    if (ytFiles.get(itag).getFormat().isDashContainer()) {
                                        numNotDash = i;
                                        break;
                                    }
                                }
                                itag = ytFiles.keyAt(new Random().nextInt(ytFiles.size() - numNotDash) + numNotDash);
                                newLink = ytFiles.get(itag).getUrl();
                              //  newLink = ytFiles.get(itag).getUrl();
                                String title = "Video Downloader";
                                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(newLink));
                                request.setTitle(title);
                                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,title+".mp4");
                                DownloadManager downloadManager = (DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
                                request.allowScanningByMediaScanner();
                                request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
                                downloadManager.enqueue(request);

                            }
                        }
                    }.extract(Url,true,true);
                }
            }
        });
    }
    private void initUi() {
        et_search = (EditText) findViewById(R.id.et_search);
        button_download = (Button) findViewById(R.id.button_download);
    }
}

